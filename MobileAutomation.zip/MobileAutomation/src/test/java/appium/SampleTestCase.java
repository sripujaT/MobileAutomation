package appium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.offset.PointOption;

public class SampleTestCase extends AppiumDriverBase {

	public SampleTestCase(AndroidDriver driver) {
	}

	@Test
	public void sampleTest() throws InterruptedException {

//sign in
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("com.ebay.mobile:id/button_sign_in")));
		driver.findElement(By.id("com.ebay.mobile:id/button_sign_in")).click();
// google sign in
		driver.findElement(By.id("com.ebay.mobile:id/button_google")).click();

//select username
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("com.google.android.gms:id/account_name")));
		driver.findElement(By.id("com.google.android.gms:id/account_name")).click();
//search bar
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("com.ebay.mobile:id/search_box")));
		driver.findElement(By.id("com.ebay.mobile:id/search_box")).click();

//sendkeys for 65 inch tv
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("com.ebay.mobile:id/search_src_text")));
		driver.findElement(By.id("com.ebay.mobile:id/search_src_text")).sendKeys("65 inch tv");
//press search
		KeyEvent ke = new KeyEvent(AndroidKey.ENTER);
		driver.pressKey(ke);

//swiping up
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("com.ebay.mobile:id/text_slot_1")));
		WebElement blueswipe = driver.findElement(By.id("com.ebay.mobile:id/text_slot_1"));
		blueswipe.click();
		Thread.sleep(2000);
		System.out.println("blue swipe");

//use co-ordinates for selecting the TV
		TouchAction ta = new TouchAction(driver);
		Thread.sleep(1000);
		ta.tap(PointOption.point(475, 1986)).release().perform();
		System.out.println("Tv selected");
		Thread.sleep(2000);

//swipe the screen to add the item to the cart
		TouchAction touch = new TouchAction(driver);
		touch.longPress(PointOption.point(530, 1600)).moveTo(PointOption.point(400, 400)).release().perform();
		System.out.println("swiped the screen up");
		Thread.sleep(3000);
		driver.findElement(By.id("com.ebay.mobile:id/button_add_to_cart")).click();
		System.out.println("click add to cart");

// goto cart
		Thread.sleep(2000);
		driver.findElement(By.id("com.ebay.mobile:id/call_to_action_button")).click();
		System.out.println("goto cart");
		
// goto checkout
		Thread.sleep(2000);
		driver.findElement(By.id("com.ebay.mobile:id/shopping_cart_checkout")).click();
		System.out.println("checkout");
		
// select payment option
		Thread.sleep(5000);
		driver.findElement(By.id("com.ebay.mobile:id/payment_chevron")).click();
		System.out.println("select payment option");
		
	}

}
